
__author__ = "Andy Dustman <andy@dustman.net>"
version_info = (1,2,1,'final',1)
__version__ = "1.2.1"
